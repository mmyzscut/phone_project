/** Automatically generated file. DO NOT MODIFY */
package com.umipay.android.umipaysdkdemo.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}